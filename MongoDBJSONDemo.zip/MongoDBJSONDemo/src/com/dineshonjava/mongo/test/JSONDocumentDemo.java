package com.dineshonjava.mongo.test;

import java.net.UnknownHostException;

import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.Mongo;
import com.mongodb.MongoException;
import com.mongodb.util.JSON;

/**
 * @author Dinesh Rajput
 *
 */
public class JSONDocumentDemo {

	public static void main(String[] args) {
 
	try {
 
		Mongo mongo = new Mongo("localhost", 27017);
		DB db = mongo.getDB("dineshonjavaDB");
 
		// get a single collection
		DBCollection collection = db.getCollection("empCollection");

		// convert JSON to DBObject directly
		DBObject dbObject = (DBObject) JSON.parse("{'empName':'Dinesh Rajput', 'empAge': 26,'salary':70000}");
 
		collection.insert(dbObject);
 
		DBCursor cursorDoc = collection.find();
		while (cursorDoc.hasNext()) {
			System.out.println(cursorDoc.next());
		}
 
		System.out.println("Done");
 
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}
 
	}

}
